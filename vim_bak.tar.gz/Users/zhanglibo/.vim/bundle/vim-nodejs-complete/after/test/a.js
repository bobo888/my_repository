var fs = require('fs');


fs
fs.
fs.read
fs[
fs["
fs['chmodSync'](



var a = {hello: 'world'},
    b = require('path'),
    // b = new A,
    // b = a;


b.


var emitter = new (require('events')).EventEmitter;
emitter.

var events = require('events');
var emitter = new events.EventEmitter();
var buffer = new Buffer;
// var buffer = new global.Buffer;
var tester = new A.B.C();

emitter.
buffer.
tester.
events.


cons



{
  "globals": {
    "Buffer": {
      "classes": [
        {
          ".self": [
            {
              "word": "write",
              "info": "buf.write(string, [offset], [length], [encoding])",
              "kind": "f"
            }
          ]
        }
      ],
      "protos": [
      ]
    }
  },
  "modules": {
    "events" {
      "classes": [
      ],
      "protos": [
      ]
    }
  },
  "vars": [
    {
      "word": "__dirname",
      "kind": "v"
    }
  ]
}








