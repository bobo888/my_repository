# Vim Snippets for Node.js
Here be various snippets for use with Vim SnipMate to make node.js development quicker and easier. You'll need snipmate installed, then just dump the contents of snippets/javascript into the directory ~/.vim/snippets/javascript.

## Examples
fs.readFile
fs.writeFile
reqsys
reqhttp
etc.
