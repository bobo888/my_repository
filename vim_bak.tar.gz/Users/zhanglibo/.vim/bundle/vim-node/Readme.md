## How to use

copy to your dict folder

    au FileType javascript set dictionary+=$HOME/.vim/dict/node.dict


### generate dict

```
./makenodedict path/to/node
```


http://stackoverflow.com/questions/8112070/any-tools-can-make-a-vim-dict-file-easier
